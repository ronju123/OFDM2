classdef OFDMExamp1 < handle
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        LenCP=16;  % Length Cyclic Prefix
        NumUsedBins=64; % Number of Bins
        BuffDat = [];  % Buffer of Frequency Data
        BuffDatTime = []; % Buffer of Time Data
        Nfft  = [];
        BinSpacing = 15e3; %LTE 15e3;  Wifi  312.5KHz
        MappingType = 'BPSK';
        NumBits = 1; 
        UsedBinIndex =[];
        epsvar=1e-30;
    end
    
    methods
        function obj=OFDMExamp1(varargin)
            
            for k=1:nargin
                switch k
                    case 1
                        obj.LenCP=varargin{1};
                    case 2
                        obj.NumUsedBins=varargin{2};
                    case 3
                        obj.MappingType=varargin{3};
                    case 4
                        obj.Nfft=varargin{4};
                    case 5
                        obj.BinSpacing=varargin{5};
                end
            end
            
            obj.BuffDat = zeros(obj.NumUsedBins,1);
            switch obj.MappingType
                    case 'BPSK'
                        obj.NumBits=1;
                    case 'QPSK'
                        obj.NumBits=2;
            end
            
            obj.UsedBinIndex = 1+rem([-obj.NumUsedBins/2:-1,1:obj.NumUsedBins/2]+obj.Nfft, obj.Nfft);
          
            obj.BuffDat = zeros(obj.Nfft,1);
        end
            

    end

end
            
       
