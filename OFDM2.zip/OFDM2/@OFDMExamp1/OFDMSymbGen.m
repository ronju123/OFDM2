function OFDMSymbGen(obj)

tmpv1 = ifft(obj.BuffDat, obj.Nfft);
cpdat1 = tmpv1(end-obj.LenCP+1:end); %tail of tmpv1;
obj.BuffDatTime = [cpdat1; tmpv1];

end

