function RunBinaryMap(obj, xin)

switch obj.MappingType
    case 'BPSK'
        %Mapping
        % b0--> -1
        %b1--> +1;
        dataout1=2*xin-1;
    case 'QPSK'
        %obj.NumbBits = 2;
        tvq = 2.^(obj.NumBits-1:-1:0);
        cdatout = zeros(obj.NumUsedBins,1);
        for LoopA = 1:length(xin)/2
            tmpval1 = xin(obj.NumBits*(LoopA-1)+1:obj.NumBits*(LoopA-1)+obj.NumBits);
            %qpskint = sum(tvq.*tmpval1);
            qpskint = tvq*tmpval1;
        
        
        switch qpskint
            case 0
                cdatout(LoopA)=exp(1i * 2*pi/8 * 5);
            case 1
                cdatout(LoopA)=exp(1i * 2*pi/8 * 3);
            case 2
                cdatout(LoopA)=exp(1i * 2*pi/8 * -1);
            case 3
                cdatout(LoopA)=exp(1i * 2*pi/8 * 1);
        end
        
        
        end
end
          obj.BuffDat(obj.UsedBinIndex) = cdatout;
%varargout{1}=dataout2;
end

