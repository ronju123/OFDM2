clc


%Basic Script 
LenCP = 16;   %Length of CP
NumBins = 12; %Number of occupied bins
NFFT = 64;  % NFFT >= NumBins
ModulationType = 'QPSK';

xindat = randi([0 1],NumBins*2,1);  %Information Source of Data
BinsUsed = [-NumBins/2: -1, 1: NumBins/2];    %approximate -2MHz to 2MHz for NumBins=12
fs = 20e6; %sampling frequency corresponds to 802.11
Ts=1/fs;    %sampling period
DeltaF= fs/NFFT;  %bin spacing in frequency

ODat = OFDMExamp1(LenCP, NumBins, ModulationType, NFFT, DeltaF);  %constructor for ODat
RunBinaryMap(ODat, xindat);     % maps modulated information carriers to frequency bins
OFDMSymbGen(ODat);   %frequency to time conversion
t1_long  = ODat.BuffDatTime;  %extract the time domain signal from the object ODat

%Create a plot script externally
%Time domain plot
figure(1)
subplot(2, 1, 1);
plot(real(t1_long));
grid on
xlabel('Time');
ylabel('Real');
subplot(2, 1, 2);
plot(imag(t1_long));
grid on
xlabel('Time');
ylabel('Imaginary');

%Frequency Domain plot of basband signal
FigParm.Title = 'Frequency Domain Plot';
FigParm.xaxis = 'Frequency in Hz';
FigParm.yaxis = 'Amplitude in dB';
FigPlotNum=2;
GoodPlotFreq(ODat, t1_long, fs, FigPlotNum, FigParm) 

%RF Modulate the baseband signal to an RF carrier frequency (low IF)
fc=2.5e6;
%t2_long= t1_long.*exp(1i*2*pi*fc*(0:NFFT+LenCP-1).'*Ts);  
t2_long = real(t1_long) .* cos(2*pi*fc*(0:NFFT+LenCP-1).'*Ts) - ...
                imag(t1_long) .* sin(2*pi*fc*(0:NFFT+LenCP-1).'*Ts);
FigParm.Title = 'IF/RF Frequency Domain Plot';
FigParm.xaxis = 'Frequency in Hz';
FigParm.yaxis = 'Amplitude in dB';
FigPlotNum=3;
%Frequency Domain plot of the IF signal 
GoodPlotFreq(ODat, t2_long, fs, FigPlotNum, FigParm) 